package com.onepieceultimate;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Initial entry point for One Piece Ultimate Mod.
 *
 * This is a starter scaffold, not a finished gameplay mod yet.
 * Register items, abilities, entities, and client UI in later development steps.
 */
public final class OnePieceUltimateMod implements ModInitializer {
    public static final String MOD_ID = "one_piece_ultimate";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("One Piece Ultimate Mod starter loaded.");
        LOGGER.info("Next development step: register Devil Fruit items and abilities.");
    }
}
